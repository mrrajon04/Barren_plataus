from 'Initialization based/Beta/beta_iris' import utils

# Use the imported modules
model = utils
print(model)